#config file containing credentials for RDS MySQL instance
db_username = "yuki"
db_password = "2Ta7yu1to6ma"
db_name = "ExampleDB"